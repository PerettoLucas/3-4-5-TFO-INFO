const movieModel = require('./movie.model');
const movieView = require('./movie.view');
const indexView = require('../index.view');
const authView = require('../auth/auth.view');


function listAction(request, response) {
    response.send(indexView.renderIndex(
        authView.head(request?.user), 
        movieView.renderList(movieModel.getAll(), request?.user)
    ));
}

function viewMovieAction(request, response) {
    movieModel.getAll().map(movie => {
        if(movie.id == request.params.id) {
            response.send(indexView.renderIndex(
                authView.head(request?.user),
                movieView.viewMovie(movie)
            ));
        }
    });


    
}

function removeAction(request, response) {
    movieModel.remove(request.params.id);
    response.redirect(request.baseUrl); 
}

function editAction(request, response) {
    let movie = { id: '-1', title: '', year: '', public: undefined, user: '' };
    if (request.params.id) {
        movie = movieModel.get(request.params.id);
    }

    response.send(
        indexView.renderIndex(
            authView.head(request?.user),
            movieView.renderMovie(movie, request?.user)
        )
    );
}

function saveAction(request, response) {
    console.log(request.body);
    const movie = {
        id: request.body.id,
        title: request.body.title,
        year: request.body.year,
        public: request.body.public == undefined ? false : true,
        user: request.body.user
    };
    movieModel.save(movie);
    response.redirect(request.baseUrl);
}

module.exports = { listAction, removeAction, editAction, saveAction, viewMovieAction };