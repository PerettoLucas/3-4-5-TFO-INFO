
function renderList(movies, user) {
    return `
        <table>
            <tr>
                <th>Titel</th>
                <th>Jahr</th>
                <th>Public</th>
                <th>Owner</th>
            </tr>
            ${movies.map(movie => 
                movie.public || movie.user == user?.username ?
                    `<tr> 
                        <td>${movie.title}</td>
                        <td>${movie.year}</td>
                        <td>${movie.public}</td>
                        <td>${movie.user}</td>
                        ${movie.user != user?.username ? `<td><a href="/movie/view/${movie.id}">Ansehen</a></td>` : ``}
                        ${movie?.user != null && movie?.user == user?.username ? 
                        `<td><a href="/movie/remove/${movie.id}">Löschen</a></td>
                         <td><a href="/movie/edit/${movie.id}">Ändern</a></td>`
                        : ``
                        }
                    </tr>`
                : ``
            )
            .join('')}
        </table>
        `;
}



function renderMovie(movie, user) {
    return `
        <form action="/movie/save" method="post">
            <input type="hidden" name="id" value="${movie?.id}">
            <div>
                <label for="title">Titel:</label>
                <input type="text" id="title" name="title" value="${movie?.title}">
                <br>
                <label for="year">Year:</label>
                <input type="number" id="year" name="year" value="${movie?.year ? `${movie?.year}` : 2000}">
                <br>
                <label for="user">User:</label>
                <input type="text" id="user" name="user" value="${user?.username}" readonly>
                <br>
                <label for="public">Public:</label>
                <input type="checkbox" id="public" name="public" value="true" ${movie?.public ? `checked` : ``}>
            </div>  
            <input type="submit" value="Speichern"> <a href="/">Back</a>
        </form>
    `;
}

function viewMovie(movie) {
    return `

        <div>
            <hr>
            Titel: ${movie?.title}
            <hr>
            Jahr: ${movie?.year}
            <hr>
            Öffentlich: ${movie?.public ? `Ja` : `Nein`}
            <hr>
            Besitzer: ${movie?.user}
        </div>
        <a href="/">Back</a>
    
    `
}

module.exports = { renderList, renderMovie, viewMovie };